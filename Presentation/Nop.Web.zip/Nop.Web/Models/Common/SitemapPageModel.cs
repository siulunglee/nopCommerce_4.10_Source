﻿using Nop.Web.Framework.UI.Paging;

namespace Nop.Web.Models.Common
{
    public partial class SitemapPageModel : BasePageableModel
    {
    }
}