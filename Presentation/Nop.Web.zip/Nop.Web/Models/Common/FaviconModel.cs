﻿using Nop.Web.Framework.Models;

namespace Nop.Web.Models.Common
{
    public partial class FaviconModel : BaseNopModel
    {
        public string FaviconUrl { get; set; }
    }
}