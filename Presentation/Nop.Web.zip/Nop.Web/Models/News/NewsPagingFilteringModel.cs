﻿using Nop.Web.Framework.UI.Paging;

namespace Nop.Web.Models.News
{
    public partial class NewsPagingFilteringModel : BasePageableModel
    {
    }
}