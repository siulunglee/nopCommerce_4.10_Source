﻿namespace Nop.Web.Models.Checkout
{
    public class UpdateSectionJsonModel
    {
        public string name { get; set; }
        public string html { get; set; }
    }
}