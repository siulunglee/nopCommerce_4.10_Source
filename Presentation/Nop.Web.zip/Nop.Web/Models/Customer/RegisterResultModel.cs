﻿using Nop.Web.Framework.Models;

namespace Nop.Web.Models.Customer
{
    public partial class RegisterResultModel : BaseNopModel
    {
        public string Result { get; set; }
    }
}