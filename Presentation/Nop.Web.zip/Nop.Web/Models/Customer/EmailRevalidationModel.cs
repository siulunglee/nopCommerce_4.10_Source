﻿using Nop.Web.Framework.Models;

namespace Nop.Web.Models.Customer
{
    public partial class EmailRevalidationModel : BaseNopModel
    {
        public string Result { get; set; }
    }
}