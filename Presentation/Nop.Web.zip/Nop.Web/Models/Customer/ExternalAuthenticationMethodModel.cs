﻿using Nop.Web.Framework.Models;

namespace Nop.Web.Models.Customer
{
    public partial class ExternalAuthenticationMethodModel : BaseNopModel
    {
        public string ViewComponentName { get; set; }
    }
}