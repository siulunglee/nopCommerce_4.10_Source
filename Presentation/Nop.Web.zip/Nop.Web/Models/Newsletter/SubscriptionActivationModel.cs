﻿using Nop.Web.Framework.Models;

namespace Nop.Web.Models.Newsletter
{
    public partial class SubscriptionActivationModel : BaseNopModel
    {
        public string Result { get; set; }
    }
}